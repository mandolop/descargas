<?php

namespace AC\Admin;

interface ScreenOptions {

	/**
	 * @return ScreenOption[]
	 */
	public function get_screen_options();

}