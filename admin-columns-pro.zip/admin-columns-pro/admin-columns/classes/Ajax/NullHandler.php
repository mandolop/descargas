<?php

namespace AC\Ajax;

class NullHandler extends Handler {

	public function register() {

	}

}