<?php

namespace AC;

interface Installer {

	public function install();

}